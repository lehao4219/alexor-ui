---
title: Kanban
---

# Kanban

The `Kanban` component.
