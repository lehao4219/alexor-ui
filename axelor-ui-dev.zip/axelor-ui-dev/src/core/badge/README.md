---
title: Badge
---

# Badge

The `Box` component as Badge.
