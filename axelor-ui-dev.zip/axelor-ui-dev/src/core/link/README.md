---
title: Link
---

# Link

The `Box` component as Link.
