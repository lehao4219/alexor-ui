---
title: Panel
---

# Panel

The `Panel` component.
