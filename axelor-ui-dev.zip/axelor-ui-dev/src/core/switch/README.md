---
title: Switch
---

# Switch

The `Switch` component implemented using `Input` component.
