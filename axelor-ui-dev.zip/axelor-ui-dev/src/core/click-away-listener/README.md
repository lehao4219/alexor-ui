---
title: Click Away Listener
---

# Click Away Listener

The `ClickAwayListener` component.
