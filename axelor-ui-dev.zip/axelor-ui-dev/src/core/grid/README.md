---
title: Grid
---

# Grid

The `Box` component with grid layout.
