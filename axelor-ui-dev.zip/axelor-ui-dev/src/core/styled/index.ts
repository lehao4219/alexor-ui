import styled from "./styled";

export * from "./styled";
export { styled as default };
