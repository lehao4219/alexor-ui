---
title: Button
---

# Button

The `Button` component.
