---
title: Image
---

# Image

The `Image` component.
