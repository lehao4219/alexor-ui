---
title: Overflow
---

# Overflow

The `Overflow` component. It's based on [fluent-ui overflow](https://github.com/microsoft/fluentui/tree/master/packages/react-components/priority-overflow) component but using stadard css.
