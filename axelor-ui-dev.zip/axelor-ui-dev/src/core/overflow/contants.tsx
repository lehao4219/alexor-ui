export const DATA_OVERFLOWING = "data-overflowing";
export const DATA_OVERFLOW_ITEM = "data-overflow-item";
export const DATA_OVERFLOW_MENU = "data-overflow-menu";
export const DATA_OVERFLOW_DIVIDER = "data-overflow-divider";
