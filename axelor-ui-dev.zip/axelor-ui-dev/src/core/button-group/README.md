---
title: Button Group
---

# Button Group

The `ButtonGroup` component.
