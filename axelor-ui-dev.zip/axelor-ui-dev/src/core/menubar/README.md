---
title: Menubar
---

# Menubar

The `Menubar` component.
