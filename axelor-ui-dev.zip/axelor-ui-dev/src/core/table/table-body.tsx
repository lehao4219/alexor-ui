import styled from "../styled";

export interface TableBodyProps {}

export const TableBody = styled.tbody<TableBodyProps>();
