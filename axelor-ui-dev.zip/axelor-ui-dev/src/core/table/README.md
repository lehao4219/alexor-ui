---
title: Table
---

# Table

The `Table` component.
