---
title: Slide
---

# Slide

The `Slide` component.
