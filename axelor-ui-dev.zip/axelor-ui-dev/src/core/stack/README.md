---
title: Stack
---

# Stack

The `Box` component that makes flexbox layout simple and easier.
