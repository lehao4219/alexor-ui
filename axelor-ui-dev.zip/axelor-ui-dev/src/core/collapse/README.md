---
title: Collapse
---

# Collapse

The `Collapse` component.
