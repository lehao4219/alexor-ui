import styled from "../styled";

export const MenuHeader = styled.div(
  () => ["dropdown-header"],
  () => ({ "aria-disabled": true }),
);
