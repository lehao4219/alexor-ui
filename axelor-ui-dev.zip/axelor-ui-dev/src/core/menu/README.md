---
title: Menu
---

# Menu

The `Menu` component.
