---
title: Divider
---

# Divider

The `Divider` component.
