---
title: Focus Trap
---

# Focus Trap

The `FocusTrap` component.
