---
title: Tree
---

# Tree

The `Tree` component.
