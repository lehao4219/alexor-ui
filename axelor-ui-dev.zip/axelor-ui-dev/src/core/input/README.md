---
title: Input
---

# Input

The `Input` component.
