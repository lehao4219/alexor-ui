---
title: Accordion
---

# Accordion

The `Accordion` component.
