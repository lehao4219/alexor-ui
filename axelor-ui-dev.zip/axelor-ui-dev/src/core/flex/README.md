---
title: Flex
---

# Flex

The `Box` component with flex layout.
