import { SvgIcon, SvgIconProps } from "../../icons/svg-icon";

/**
 *
 * @deprecated
 */
export type IconProps = SvgIconProps;

/**
 *
 * @deprecated use SvgIcon
 */
export const Icon = SvgIcon;
