---
title: LinearProgress
---

# LinearProgress

The `LinearProgress` component.
