---
title: CircularProgress
---

# CircularProgress

The `CircularProgress` component.
