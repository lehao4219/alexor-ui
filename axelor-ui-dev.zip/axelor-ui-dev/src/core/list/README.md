---
title: List
---

# List

The `List` component.
