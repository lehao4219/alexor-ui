---
title: Fade
---

# Fade

The `Fade` component.
