---
title: InputLabel
---

# InputLabel

The `InputLabel` component.
