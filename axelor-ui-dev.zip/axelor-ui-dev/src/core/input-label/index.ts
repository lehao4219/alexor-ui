export * from "./input-label";
