---
title: Box
---

# Box

The `Box` component.
