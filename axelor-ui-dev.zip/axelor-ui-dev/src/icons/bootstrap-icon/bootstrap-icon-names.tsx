import iconNames from "bootstrap-icons/font/bootstrap-icons.json";

// All bootstrap icons names
export const bootstrapIconNames = new Set(Object.keys(iconNames));