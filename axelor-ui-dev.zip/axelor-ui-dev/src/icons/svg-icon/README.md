---
title: SvgIcon
---

# SvgIcon

The `SvgIcon` component.
