export * from "./svg-icon";
