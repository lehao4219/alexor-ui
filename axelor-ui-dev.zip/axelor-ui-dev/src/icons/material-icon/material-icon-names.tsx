import iconNames from "@material-symbols/metadata/versions.json";

// All material icons names
export const materialIconNames = new Set(Object.keys(iconNames));